from django import forms
from .models import  Register
from django.contrib.auth.models import User
from .models import Profile


class RegisterForm(forms.ModelForm):
    class Meta:
        model  = Register
        fields = "__all__" 
        #exclude = ['user']

        widgets = {

            'username': forms.TextInput(attrs = {'class':'form-control','placeholder':'Enter username','id':'username'}),
            'password' : forms.TextInput(attrs = {'type':'password','class':'form-control','id':'password','placeholder':'Enter password'}),
            'confirmpassword' : forms.TextInput(attrs = {'type':'password','class':'form-control','id':'confirmpassword','placeholder':'Retype password'}),
            'email': forms.TextInput(attrs = {'class':'form-control','placeholder':'Enter email'}),
            'firstname' : forms.TextInput(attrs = {'class':'form-control','placeholder':'Enter first name'}),
            'lastname' : forms.TextInput(attrs = {'class':'form-control','placeholder':'Enter last name'}),

            }

        #   # To leave a label blank.
        # label = {
        #     'name': '',
        #     'email':'',
        #     'username':'', 
        #     'password':'',
        #     'address':'',
      
        #    }

class UserUpdateForm(forms.ModelForm):

    class Meta:
        model = User
        fields = ['username', 'email','first_name','last_name']


class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['image']