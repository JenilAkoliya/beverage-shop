from django.db import models
from django.contrib.auth.models import User
import datetime




# Create your models here.
class Contact(models.Model):
    name= models.CharField(max_length=100)
    email=models.CharField(max_length=30)
    phone=models.CharField(max_length=12)
    desc=models.TextField(max_length=500)
    date=models.DateField()

  

#now you will see in database that it will shows the list with name like contact3,contact4 .but if u want to see the list by 
# customer name then u will have to add __repr__ function

    def __str__(self):
        return self.name




class Contactemail(models.Model):
    subscriberemail= models.CharField(max_length=30)


    def __str__(self):
        return self.subscriberemail


class Product(models.Model): 
    name = models.CharField(max_length=200)  
    image = models.ImageField(blank=True, upload_to="profilepics",default="")  
    price = models.FloatField()   


    
 
class  Register(models.Model):
        id = models.AutoField(primary_key=True)
        username =  models.CharField(max_length = 255)
        password = models.CharField(max_length = 20)
        confirmpassword =models.CharField(max_length = 20,)
        email = models.EmailField(max_length= 50,null = True)
        firstname = models.CharField(max_length=200)  
        lastname = models.CharField(max_length=20) 
        #myimage = models.ImageField(blank=True, upload_to="profilepics")
        
  
        
        def __str__(self):
            return str(self.username)


class Profile(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE,)
    image = models.ImageField(default='default.jpg',upload_to='profilepics')        

    def __str__(self):
        return f'{self.user.username} Profile'




class Beerproduct(models.Model):
    name = models.CharField(max_length=50)
    price = models.IntegerField(default=0)
    description = models.CharField(max_length=200, default='' , null=True , blank=True)
    image = models.ImageField(upload_to='beerproducts/')        


    def __str__(self):
        return str(self.name)


    @staticmethod
    def get_all_products():
        return Beerproduct.objects.all()    

    @staticmethod
    def get_products_by_id(ids):
        return Beerproduct.objects.filter(id__in=ids)



class Order(models.Model):
    product = models.ForeignKey(Beerproduct,
                                on_delete=models.CASCADE,default="")
    customer = models.ForeignKey(User,
                                 on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    price = models.IntegerField()
    address = models.CharField(max_length=50, default='', blank=True)
    phone = models.CharField(max_length=50, default='', blank=True)
    date = models.DateField(default=datetime.datetime.today)
    status = models.BooleanField(default=False)


    def __str__(self):
        return str(self.customer)

    def placeOrder(self):
        self.save()  


    @staticmethod
    def get_orders_by_customer(_auth_user_id):
        return Order.objects.filter(customer=_auth_user_id).order_by('-date')    