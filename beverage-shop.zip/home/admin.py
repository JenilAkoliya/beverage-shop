from django.contrib import admin
from home.models import Contact
from home.models import Contactemail
from home.models import Product
from home.models import Register
from home.models import Profile
from home.models import Beerproduct
from home.models import Order





# Register your models here.
'''
class Userprofileadmin(admin.ModelAdmin):
    list_display = ['Phone'] '''







admin.site.register(Contact)
admin.site.register(Contactemail)
admin.site.register(Product)
admin.site.register(Register)
admin.site.register(Profile)
admin.site.register(Beerproduct)
admin.site.register(Order)
