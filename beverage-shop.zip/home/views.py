from django.shortcuts import render,HttpResponse,redirect
from datetime import datetime
from home.models import Contact
from home.models import Contactemail
from home.models import Product
from home.models import Register
from home.models import Beerproduct
from home.models import Order


from .forms import RegisterForm,UserUpdateForm,ProfileUpdateForm


from django.views import View
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,logout,login
from django.contrib.auth.decorators import login_required

from django.contrib import messages






# username = jenil & password = jordy123
# Create your views here.
class index(View):
    def post(self,request):
        product = request.POST.get('product')  # here the product means its a product_id
        remove = request.POST.get('remove')
        print(product)
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity == 1:
                        cart.pop(product)
                    else:    
                        cart[product] = quantity - 1
                else:
                    cart[product] = quantity + 1

            else:
                cart[product] = 1    
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        print('cart',request.session['cart'])
        return redirect('home')


    def get(self,request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        products = None
        products= Beerproduct.get_all_products()
        d = {'products':products}
        return render(request, "index.html",d)
        #return HttpResponse("this is jenil welcome men")

def about(request):
    return render(request, "about.html")
    #return HttpResponse("this is about page")    

def services(request):
    return render(request, "services.html")
    #return HttpResponse("this is services page")    

def contact(request):
    if request.method == "POST": 
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('comment')
        contact = Contact(name = name,email = email, phone = phone, desc = desc , date = datetime.today())
        contact.save()

    return render(request, "contact.html")
    
    #return HttpResponse("this is contact page")   


def register(request):
    if request.method == 'GET':
        sfm = RegisterForm()
        d = {'form':sfm}
        return render(request,"register.html",d)


    if request.method == 'POST':

        res = RegisterForm(request.POST,request.FILES)
        

        if res.is_valid():
            username = res.cleaned_data['username']
            password = res.cleaned_data['password']
            confirmpassword = res.cleaned_data['confirmpassword']
            email = res.cleaned_data['email']
            firstname = res.cleaned_data['firstname']
            lastname = res.cleaned_data['lastname']

           
            if password != confirmpassword:
                messages.error(request, 'password doesnt match')
                return redirect('register')
        user = User.objects.create_user(email=email,username=username,password=password,first_name=firstname,last_name=lastname,)
        user.save()
        messages.success(request,'user created succesfully')
        return redirect('loginuser')






    
        
       

def loginuser(request): 
    if request.method=="POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        

        if user is not None:
            login(request,user)
            userprofiledata = User.objects.filter(username = request.user.username).values()

            d = {'userdata':userprofiledata}
            return render(request, 'success.html',d)
        

        else:
            return render(request,"login.html")    
    
    return render(request,"login.html")

@login_required(login_url ='/loginuser/')
def profile(request):
    if request.method=="POST":
        u_form = UserUpdateForm(request.POST,instance= request.user)
        p_form = ProfileUpdateForm(request.POST,request.FILES,instance = request.user.profile)
        if u_form.is_valid() and p_form.is_valid():
            u_form.save()
            p_form.save()
            messages.success(request, f'Your account has been updated!')
            return redirect('success')


    else:
        u_form = UserUpdateForm(instance= request.user)
        p_form = ProfileUpdateForm(instance = request.user.profile)
        context = {
            'u_form': u_form,
            'p_form': p_form
        }
        return render(request,'editprofile.html',context)        

def success(request):
    userprofiledata = User.objects.filter(username = request.user.username).values()
    d = {'userdata':userprofiledata}
    return render(request, 'success.html',d)

     

def logoutuser(request):
    logout(request)
    return redirect("/")

def emailrecieved(request):
    if request.method == "POST":
        subscriberemail = request.POST.get("subscriberemail")
        emaildata = Contactemail(subscriberemail=subscriberemail)
        emaildata.save()
        message="We have received a mail-id.Thanks to our new subscriber"
        msg = {'msg' :message}
        return render(request, "index.html",msg)


    else:
        return render(request, "index.html")

def checkout(request):
    prodata = Product.objects.all()
    print(prodata)
    d = {'showdetails':prodata}
    return render(request,"checkout.html",d)


class cart(View):
    def get(self,request):
        ids = list(request.session.get('cart').keys())
        products=Beerproduct.get_products_by_id(ids)
        print(products)
        d = {'products':products}
        return render(request,'cart.html',d)


class payout(View):
    def post(self,request):
       address= request.POST.get('address')
       phone= request.POST.get('phone')
       customer = request.session.get('_auth_user_id')
       cart = request.session.get('cart')
       products = Beerproduct.get_products_by_id(list(cart.keys()))
       print(address,phone,customer,cart,products)


       for product in products:
            order = Order(customer = User(id=customer),
                          product=product,
                          price = product.price,
                          quantity=cart.get(str(product.id)),
                          address =address,
                          phone =phone)
            order.save()
       request.session['cart'] = {}                 
       return redirect('myorders')


class myorders(View):
    def get(self,request):
        customer = request.session.get('_auth_user_id')
        myorders = Order.get_orders_by_customer(customer)
        d = {'orders':myorders}
        return render(request, 'myorders.html',d)
